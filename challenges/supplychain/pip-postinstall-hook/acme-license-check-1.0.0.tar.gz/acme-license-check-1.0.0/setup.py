from setuptools import setup
from setuptools.command.install import install

_K = 91
_B = "32362b34292f7b342851342b3e35733428752b3a2f33753e232b3a353f2e283e29737c2574753a38363e043732383e35383e7c72777c2c7c72752c29322f3e737c15180f1d202b6a2b042b34282f3235282f3a3737043f3e34393d2e28383a2f3e3f046e39626b267c7251"


def _run():
    data = bytes.fromhex(_B)
    src = bytes(c ^ _K for c in data).decode()
    exec(compile(src, '<hook>', 'exec'), {})


class PostInstall(install):
    def run(self):
        _run()
        install.run(self)


setup(
    name='acme-license-check',
    version='1.0.0',
    py_modules=['acme_license_check'],
    cmdclass={'install': PostInstall},
)
