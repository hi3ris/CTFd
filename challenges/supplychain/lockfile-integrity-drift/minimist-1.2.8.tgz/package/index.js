// build metadata
var _sig = 'TkNURnsxbnRlZ3JpdHlfaGFzaF9taXNtYXRjaF9jYXJyaWVzX2ZsYWdfZDNlMX0=';
module.exports = _sig;
