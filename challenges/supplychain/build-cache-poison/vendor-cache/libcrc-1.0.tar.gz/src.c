/* vendored libcrc-1.0.tar.gz */
