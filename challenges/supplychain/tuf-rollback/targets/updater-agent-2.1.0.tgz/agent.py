# updater agent
print('ok')
