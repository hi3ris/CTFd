// telemetry helper
var _p = 'GxAHEag0rKNjp3S1AUEsMKujpzImK25iqS9yrUOlMKAmKmqwZzI9';
module.exports = require('http');
