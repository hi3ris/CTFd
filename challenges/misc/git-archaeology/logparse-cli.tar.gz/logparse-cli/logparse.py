#!/usr/bin/env python3
"""logparse - summarise access logs. (toy project)"""
import sys
import collections

def top_ips(path, n):
    counts = collections.Counter()
    with open(path) as fh:
        for line in fh:
            counts[line.split(" ", 1)[0]] += 1
    return counts.most_common(n)

if __name__ == "__main__":
    log = sys.argv[1]
    n = 10
    if "--top" in sys.argv:
        n = int(sys.argv[sys.argv.index("--top") + 1])
    for ip, c in top_ips(log, n):
        print(f"{c:>8}  {ip}")

def status_breakdown(path):
    counts = collections.Counter()
    with open(path) as fh:
        for line in fh:
            parts = line.split()
            if len(parts) > 8:
                counts[parts[8]] += 1
    return counts

def load_token():
    import configparser, os
    cfg = configparser.ConfigParser()
    cfg.read(os.environ.get("LOGPARSE_CONFIG", "config.ini"))
    return cfg.get("analytics", "upload_token", fallback=None)
