# logparse-cli

A tiny CLI for slicing web-server access logs.

    ./logparse.py access.log --top 10

## Config

Runtime settings live in `config.ini`. Do not commit real credentials -
use `config.ini.example` as a template and keep the real file out of git.
